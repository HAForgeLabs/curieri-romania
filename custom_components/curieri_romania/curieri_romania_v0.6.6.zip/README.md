# Curieri Romania

Versiune curenta: v0.6.6

Versiune: v0.6.6

Integrare Home Assistant pentru monitorizarea coletelor prin curierii din Romania.

## Versiune

v0.6.6

## Stadiu curent

- Sameday functional in test, prin refresh token extras cu helper local sau, alternativ, prin flux web OAuth/OIDC cu PKCE.
- Se creeaza senzori agregati pentru colete active, livrate si cu probleme.
- Se creeaza senzori individuali pentru fiecare colet gasit.
- Pentru coletele active Sameday se apeleaza si endpointul de detalii pentru completarea istoricului/evenimentelor, unde datele exista.
- Exista panel dedicat `Curieri Romania` in bara laterala Home Assistant.
- FAN Courier este activat in regim de test, cu username si parola; cheia aplicatiei mobile este inclusa intern in provider.
- Pentru FAN Courier se citesc endpointurile `active`, `registered`, `history` si `details`, cu paginare si suport pentru mai multe branch-uri.
- Cargus este activat in regim beta/test, cu autentificare automata prin email si parola, plus metoda avansata cu helper/bookmarklet sau refresh token manual. Parola este folosita doar la configurare si nu este salvata.
- GLS este activat in regim beta/test, cu autentificare automata prin email si parola; parola este folosita doar la configurare si nu este salvata. Access tokenul se improspateaza automat din refresh token.

## Atentie

Debugul este inca activ controlat pentru etapa de test. Nu logheaza tokenuri, cookie-uri, PIN-uri sau date personale intentionat, dar inainte de release public trebuie curatat sau facut optional.

## Instalare

Copiaza folderul `custom_components/curieri_romania` in `/config/custom_components/curieri_romania`, apoi reporneste Home Assistant.

Dupa restart:

1. Adauga integrarea `Curieri Romania` pentru administrare.
2. Adauga din nou `Curieri Romania` si selecteaza curierul dorit.
3. Pentru Sameday: introducerea tokenului este semi-automata. Home Assistant deschide helperul local, instalezi o singura data bookmarkletul, te loghezi in Sameday si apesi bookmarkletul. Tokenul este trimis automat inapoi in Home Assistant. Alternativ, ramane disponibila metoda avansata cu URL callback OAuth.
4. Pentru FAN Courier: introdu username-ul si parola. Integrarea obtine automat clientId-ul real din endpointul branches si nu mai cere telefon.
5. Pentru Cargus: alege metoda recomandata `Email si parola Cargus`, introdu telefonul exact din cont, emailul si parola, iar integrarea obtine automat refresh tokenul prin Azure B2C. Parola nu este salvata dupa configurare. Metoda cu helper/bookmarklet si metoda cu refresh token manual raman disponibile ca optiuni avansate.
6. Pentru GLS: alege metoda recomandata `Email si parola GLS`, introdu datele contului GLS, iar integrarea obtine automat refresh tokenul prin Azure B2C/MSAL. Parola nu este salvata dupa configurare. Metoda cu refresh token manual ramane doar avansata.

## Dashboard

Panelul dedicat `Curieri Romania` se inregistreaza automat si afiseaza coletele individuale existente in Home Assistant, cu status, expeditor, locatie, ramburs, expirare PIN si ultima actualizare.


## v0.6.6

- Cargus: adaugata autentificare automata cu email si parola, folosind fluxul Azure B2C validat in scriptul local `cargus_auth_test_v2.py`.
- La configurarea Cargus se cere in continuare telefonul contului, deoarece API-ul MyCargus il foloseste la generarea headerului `K`.
- Parola Cargus este folosita doar la configurare si nu este salvata in config entry. Se salveaza access tokenul temporar, refresh tokenul si expirarea tokenului.
- Pastrata metoda avansata cu helper/bookmarklet Cargus si metoda cu refresh token manual.
- Adaugat diagnostic automat sigur pentru Cargus auth in logurile Home Assistant, cu prefixul `[CARGUS AUTH DIAG]`. Logurile indica pasul unde pica fluxul, dar nu includ parola, tokenuri, cookie-uri sau coduri OAuth complete.
- Nu au fost modificate panelul, Sameday, FAN Courier sau GLS.

## v0.6.4

- GLS: adaugata autentificare automata cu email si parola, fara mitmproxy, fara copiere de token si fara copiere de URL `msauth://`.
- Config flow-ul reproduce fluxul Azure B2C/MSAL al aplicatiei GLS: authorize, SelfAsserted, confirmed si token exchange cu PKCE.
- Parola GLS este folosita doar in timpul configurarii si nu este salvata in config entry. Se salveaza doar access tokenul temporar, refresh tokenul si expirarea tokenului.
- Metoda browser OAuth GLS ramane disponibila doar ca metoda de diagnostic, iar refresh tokenul manual ramane metoda avansata.
- Nu au fost modificate providerii Sameday, FAN Courier sau Cargus si nu a fost modificat panelul.

## v0.6.3

- Corectat regresia din panel: fisierul frontend a fost readus la baza stabila v0.6.0, astfel incat click pe card sa deschida din nou drawerul cu detalii.
- GLS ramane activat in regim beta, dar configurarea nu mai depinde de extragerea refresh tokenului din aplicatia mobila.
- Adaugata metoda recomandata `Autentificare GLS prin browser`, cu OAuth/PKCE si copiere manuala a URL-ului final `msauth://...` in config flow.
- Metoda `Refresh token GLS manual` ramane disponibila doar ca metoda avansata.
- GLS regenereaza automat access tokenul din refresh token si salveaza noul refresh token returnat de server.
- GLS citeste colete active/recente din `platform/v2/parcels/recently`.
- GLS citeste istoricul pentru colete primite si trimise din `platform/v1/parcels/history`.
- Adaugata normalizare initiala pentru statusurile GLS: PREPARING, SHIPPED, IN_DELIVERY, PICK_UP, PICKED_UP, DELIVERED, FAILED, DAMAGED, REFUSED, CANCELLED.
- Modelul comun si senzorii individuali pot expune PIN locker, telefon curier, interval de livrare, tip livrare si adresa/punct de livrare, unde curierul le returneaza.

## v0.6.0

- Imbunatatit fluxul helperelor Sameday si Cargus.
- Bookmarkletul trimite automat refresh tokenul inapoi catre Home Assistant prin endpointul local `/api/curieri_romania/token_result`.
- Config flow-ul poate prelua tokenul din helper fara copiere/lipire manuala.
- Pentru Cargus, telefonul este cerut inainte de deschiderea helperului, apoi tokenul este preluat automat.
- Pentru Sameday, tokenul este preluat automat si configurarea incearca sa creeze intrarea direct.
- Daca transmiterea automata esueaza, formularele pastreaza fallback manual pentru lipirea refresh tokenului.
- Helper-ele au instructiuni mai clare si buton direct pentru deschiderea portalului oficial al curierului.

## v0.5.8

- Corectat finalizarea pasului extern pentru helper-ele Sameday si Cargus.
- Endpointul `/api/curieri_romania/external_step_done` foloseste acum managerul corect `hass.config_entries.flow.async_configure`, astfel incat flow-ul sa poata continua dupa apasarea butonului din helper.
- Pasul extern ramane metoda oficiala pentru deschiderea helperului, iar dupa copierea tokenului flow-ul trebuie sa avanseze catre formularul in care se lipeste refresh tokenul.
- Nu se modifica providerii Sameday, FAN Courier sau Cargus.
- Helper-ele din panel raman disponibile ca alternativa.

## 0.5.6

- Helperul Cargus si helperul Sameday sunt servite direct de integrare ca pagini statice Home Assistant.
- Formularele Sameday si Cargus includ link direct catre helperul potrivit.
- Userul nu mai trebuie sa caute manual fisierele din arhiva pentru extragerea refresh tokenului.
- Tokenurile sunt citite local in browser prin bookmarklet si nu sunt trimise catre niciun server extern.

## 0.5.4

- Adaugat helper local pentru extragerea refresh tokenului Sameday dupa autentificarea in portalul oficial.
- Helperul este disponibil in `tools/sameday_refresh_token_helper.html`.
- Config flow Sameday permite acum metoda recomandata cu refresh token extras cu helperul.
- Metoda veche cu URL callback OAuth ramane disponibila ca metoda avansata.
- Home Assistant valideaza refresh tokenul Sameday, obtine access token initial si il reinnoieste automat ulterior.

### Helper refresh token Sameday

1. Deschide local `tools/sameday_refresh_token_helper.html`.
2. Trage bookmarkletul `Extrage token Sameday` in bara de bookmarks.
3. Intra pe `https://sameday.ro/trimite-colete` si autentifica-te normal.
4. Apasa bookmarkletul.
5. Copiaza tokenul afisat si lipeste-l in configurarea Sameday din Home Assistant.

## 0.5.3

- Adaugat helper local pentru extragerea refresh tokenului MyCargus dupa autentificarea in portalul oficial.
- Helperul este disponibil in `tools/cargus_refresh_token_helper.html`.
- Nu modifica logica de interogare Sameday, FAN Courier sau Cargus.

## 0.5.0

- Cargus nu mai cere access token Bearer manual in configurare.
- Config flow Cargus cere telefonul exact din cont si refresh tokenul MSAL extras din portalul MyCargus.
- Integrarea schimba automat refresh tokenul in access token prin endpointul Azure B2C al Cargus.
- Access tokenul este pastrat temporar si reinnoit automat inainte de expirare.
- Daca Azure B2C returneaza refresh token nou, acesta este salvat automat in config entry.
- Se pastreaza compatibilitate cu intrarile vechi bazate pe access token manual, pentru test local.

### Helper temporar pentru extragere refresh token Cargus

Dupa login in `https://mycargus.cargus.ro`, ruleaza in consola browserului helperul de mai jos si copiaza doar valoarea afisata ca `refresh_token`.

```javascript
(() => {
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (!key || !key.toLowerCase().includes("refreshtoken")) {
      continue;
    }
    try {
      const obj = JSON.parse(localStorage.getItem(key));
      if (obj && obj.secret) {
        console.log("refresh_token:", obj.secret);
        return;
      }
    } catch (e) {}
  }
  console.log("Nu am gasit refresh token Cargus.");
})();
```

## 0.4.9

- Cargus activat initial in regim beta/test.
- Config flow Cargus cere telefonul exact din contul MyCargus si access token-ul Bearer copiat local din portal.
- Implementat algoritmul de generare a headerului `K` pe baza telefonului, conform bibliotecii PhoneKey din portalul web MyCargus.
- Cargus interogheaza `AwbList` pentru `shipmentType` 0..4 si deduplica AWB-urile.
- Cargus incearca sa incarce `FullAwb` pentru detalii si istoric, cu limita de siguranta pe update.
- Cargus creeaza senzori individuali si coletele apar in panelul dedicat, la fel ca Sameday si FAN Courier.
- Loginul automat Azure B2C/MSAL nu este inca implementat; tokenul manual este solutie de test.

## 0.4.8

- Panelul dedicat afiseaza acum detalii proprii pentru colet la click pe card, fara sa deschida direct fereastra standard Home Assistant.
- Adaugat drawer lateral cu rezumat colet, AWB, curier, expeditor, destinatar, locatie, ramburs, PIN, estimare livrare, data livrare si ultima actualizare.
- Istoricul de livrare este afisat ca timeline vizual, folosind evenimentele detaliate existente in atributele coletului.
- A ramas disponibil un buton pentru deschiderea entitatii Home Assistant, pentru debug si verificari avansate.

## 0.4.6

- FAN Courier interogheaza toate branch-urile returnate de `GET /reports/mobile/branches`, nu doar primul branch.
- FAN Courier apeleaza `GET /mobile/v2/awb/details` pentru coletele unice, cu limita de siguranta pe update.
- Evenimentele complete returnate de endpointul `details` sunt mapate in modelul comun `ParcelEvent`, unde API-ul le returneaza.
- Deduplicare imbunatatita pentru coletele FAN aparute in mai multe liste sau branch-uri.

## 0.4.5

- Corectat interpretarea orelor FAN Courier: datele fara fus orar sunt tratate ca ora locala Romania, asa cum apar in aplicatia FAN Courier.
- Evita afisarea in Home Assistant cu +3 ore fata de aplicatia FAN Courier.
- Nu modifica logica de login, clientId, paginare sau parsare colete FAN.

## 0.4.4

- FAN Courier obtine automat clientId-ul real din `GET /reports/mobile/branches`.
- Corectat bugul in care integrarea folosea `userId` din login ca `clientId`, ceea ce producea `HTTP 404` pe `active`, `registered` si `history`.
- Eliminat campul telefon din configurarea FAN Courier.
- FAN Courier foloseste doar username/email si parola in config flow.
- Cheia aplicatiei mobile FAN Courier ramane inclusa intern in provider.
- Validarea initiala FAN verifica si endpointul `branches`, nu doar loginul.


## v0.4.8

- Sameday: se incearca incarcarea detaliilor pentru coletele din istoric, nu doar pentru cele active.
- Panel: timeline-ul din drawer poate afisa si evenimentele Sameday acolo unde endpointul de detalii le returneaza.
- Detaliile Sameday sunt limitate pe update pentru a evita requesturi excesive.


## v0.5.3

- Imbunatatire Cargus: evenimentele din FullAwb folosesc acum campul real `event`, nu eticheta generica `Eveniment`.
- Timeline-ul Cargus afiseaza descrierile reale ale evenimentelor si locatia compusa din localitate/judet, unde exista.
- Normalizare Cargus imbunatatita pentru evenimente de colectare, consolidare si ajungere in depozit.


## v0.5.6

- Adauga butoane vizibile in panelul Curieri Romania pentru Helper Sameday si Helper Cargus.
- Helper-ele pot fi deschise direct din sidebar/panel, fara cautarea fisierelor din arhiva.
- Config flow-ul mentioneaza explicit si URL-urile locale ale helperelor, pentru cazurile in care Home Assistant nu randaza linkuri clickable in descrieri.


## 0.6.4

- Ajustat URL-ul de autentificare GLS prin browser cu parametri MSAL Android suplimentari.
