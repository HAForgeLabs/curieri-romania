"""Butoane pentru administrarea Curieri Romania."""

from __future__ import annotations

from homeassistant.components.button import ButtonEntity
from homeassistant.components import persistent_notification
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import EntityCategory
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import ADMIN_ENTRY_TITLE, CONF_ENTRY_TYPE, DOMAIN, ENTRY_TYPE_ADMIN


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Configureaza butoanele pentru intrarea de administrare."""

    if entry.data.get(CONF_ENTRY_TYPE) != ENTRY_TYPE_ADMIN:
        return

    async_add_entities([CurieriRomaniaAddServiceButton(hass, entry)])


class CurieriRomaniaAddServiceButton(ButtonEntity):
    """Buton administrativ pentru adaugarea unui serviciu de curierat."""

    _attr_has_entity_name = True
    _attr_translation_key = "add_service"
    _attr_entity_category = EntityCategory.CONFIG

    def __init__(self, hass: HomeAssistant, entry: ConfigEntry) -> None:
        """Initializeaza butonul."""

        self.hass = hass
        self._attr_unique_id = f"{entry.entry_id}_add_service"
        self._attr_device_info = {
            "identifiers": {(DOMAIN, entry.entry_id)},
            "name": ADMIN_ENTRY_TITLE,
            "manufacturer": "HAForge Labs",
            "model": "Curieri Romania Admin",
        }

    async def async_press(self) -> None:
        """Afiseaza instructiuni pentru deschiderea flow-ului de adaugare serviciu.

        Home Assistant nu permite unei entitati ButtonEntity sa deschida direct
        modalul nativ de config flow. Folosim o notificare persistenta cu pasii
        standard, iar flow-ul de adaugare serviciu este disponibil din UI prin
        Adauga hub -> Curieri Romania.
        """

        message = (
            "Pentru a adauga un curier nou, mergi la Setari -> Dispozitive si servicii "
            "-> Adauga hub -> Curieri Romania. Se va deschide lista de servicii, "
            "unde poti alege Sameday, FAN Courier sau Cargus."
        )
        persistent_notification.async_create(
            self.hass,
            message,
            title="Curieri Romania - Adauga serviciu",
            notification_id="curieri_romania_add_service",
        )
