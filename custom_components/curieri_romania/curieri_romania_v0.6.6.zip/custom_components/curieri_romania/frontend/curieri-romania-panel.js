class CurieriRomaniaPanel extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: "open" });
    this._hass = null;
    this._selectedEntityId = null;
  }

  set hass(hass) {
    this._hass = hass;
    this._render();
  }

  get hass() {
    return this._hass;
  }

  connectedCallback() {
    this._render();
  }

  _getParcels() {
    if (!this._hass || !this._hass.states) {
      return [];
    }
    return Object.entries(this._hass.states)
      .map(([entityId, state]) => ({ entityId, state }))
      .filter(({ state }) => state?.attributes?.courier && state?.attributes?.awb)
      .map(({ entityId, state }) => ({
        entityId,
        status: state.state,
        awb: state.attributes.awb || "",
        awbShort: state.attributes.awb_short || state.attributes.awb || "",
        courier: state.attributes.courier || "",
        direction: state.attributes.direction || "",
        originalStatus: state.attributes.original_status || "Necunoscut",
        sender: state.attributes.sender || "Necunoscut",
        recipient: state.attributes.recipient || "Necunoscut",
        location: state.attributes.current_location || state.attributes.locker_name || "Necunoscut",
        lockerName: state.attributes.locker_name || "",
        cod: state.attributes.cash_on_delivery,
        lastUpdate: state.attributes.last_update,
        pinExpiration: state.attributes.pin_expiration_at,
        deliveredAt: state.attributes.delivered_at,
        isLocker: state.attributes.is_locker === true,
        isPickupPoint: state.attributes.is_pickup_point === true,
        hasProblem: state.attributes.has_problem === true,
        isFinal: state.attributes.is_final === true,
        friendlyName: state.attributes.friendly_name || state.attributes.display_name || entityId,
        events: Array.isArray(state.attributes.events) ? state.attributes.events : [],
        attributes: state.attributes || {},
      }))
      .sort((a, b) => {
        const weight = (p) => {
          if (!p.isFinal && p.status === "disponibil la locker") return 0;
          if (!p.isFinal && p.status === "disponibil la punct de ridicare") return 1;
          if (!p.isFinal) return 2;
          if (p.hasProblem) return 3;
          return 4;
        };
        return weight(a) - weight(b) || a.awb.localeCompare(b.awb);
      });
  }

  _statusClass(parcel) {
    if (parcel.hasProblem || ["returnat", "problema", "livrare esuata"].includes(parcel.status)) {
      return "problem";
    }
    if (parcel.status === "livrat") return "delivered";
    if (parcel.status === "disponibil la locker" || parcel.status === "disponibil la punct de ridicare") {
      return "ready";
    }
    return "active";
  }

  _formatDate(value) {
    if (!value) return "Necunoscut";
    try {
      return new Intl.DateTimeFormat("ro-RO", {
        dateStyle: "medium",
        timeStyle: "short",
      }).format(new Date(value));
    } catch (_) {
      return value;
    }
  }

  _formatMoney(value) {
    if (value === null || value === undefined || value === "") return "Necunoscut";
    const number = Number(value);
    if (!Number.isFinite(number)) return this._escape(String(value));
    if (number === 0) return "0 lei";
    return new Intl.NumberFormat("ro-RO", { style: "currency", currency: "RON" }).format(number);
  }

  _escape(value) {
    return String(value ?? "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  _openEntity(entityId) {
    const ev = new Event("hass-more-info", { bubbles: true, composed: true });
    ev.detail = { entityId };
    this.dispatchEvent(ev);
  }

  _openDetails(entityId) {
    this._selectedEntityId = entityId;
    this._render();
  }

  _closeDetails() {
    this._selectedEntityId = null;
    this._render();
  }

  _openHelper(helper) {
    const urls = {
      sameday: "/curieri_romania_tools/sameday_refresh_token_helper.html",
      cargus: "/curieri_romania_tools/cargus_refresh_token_helper.html",
    };
    const url = urls[helper];
    if (!url) return;
    window.open(url, "_blank", "noopener,noreferrer");
  }

  _render() {
    if (!this.shadowRoot) return;
    const parcels = this._getParcels();
    const selectedParcel = parcels.find((parcel) => parcel.entityId === this._selectedEntityId) || null;
    const active = parcels.filter((p) => !p.isFinal).length;
    const delivered = parcels.filter((p) => p.status === "livrat").length;
    const problems = parcels.filter((p) => p.hasProblem || ["returnat", "problema", "livrare esuata"].includes(p.status)).length;
    const ready = parcels.filter((p) => p.status === "disponibil la locker" || p.status === "disponibil la punct de ridicare").length;

    this.shadowRoot.innerHTML = `
      <style>
        :host { display: block; min-height: 100vh; background: var(--primary-background-color); color: var(--primary-text-color); }
        .wrap { max-width: 1180px; margin: 0 auto; padding: 28px 18px 40px; }
        .header { display: flex; align-items: center; justify-content: space-between; gap: 16px; margin-bottom: 20px; }
        h1 { font-size: 28px; margin: 0; font-weight: 700; }
        .subtitle { color: var(--secondary-text-color); margin-top: 6px; }
        .stats { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 12px; margin: 18px 0 24px; }
        .helpers { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; margin: 0 0 22px; }
        .helper-card { background: var(--card-background-color); border: 1px solid var(--divider-color); border-radius: 18px; padding: 16px; display: flex; justify-content: space-between; gap: 14px; align-items: center; }
        .helper-title { font-size: 15px; font-weight: 800; margin-bottom: 4px; }
        .helper-text { color: var(--secondary-text-color); font-size: 13px; line-height: 1.4; }
        .helper-button { border: 0; border-radius: 999px; padding: 10px 14px; background: var(--primary-color); color: var(--text-primary-color, #fff); font-weight: 800; cursor: pointer; white-space: nowrap; }
        .helper-button:hover { filter: brightness(1.05); }
        .stat, .card { background: var(--card-background-color); border: 1px solid var(--divider-color); border-radius: 18px; box-shadow: var(--ha-card-box-shadow, none); }
        .stat { padding: 16px; }
        .stat .label { color: var(--secondary-text-color); font-size: 13px; }
        .stat .value { font-size: 28px; font-weight: 800; margin-top: 8px; }
        .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 14px; }
        .card { padding: 16px; cursor: pointer; transition: transform .12s ease, border-color .12s ease; }
        .card:hover { transform: translateY(-1px); border-color: var(--primary-color); }
        .top { display: flex; justify-content: space-between; align-items: start; gap: 12px; }
        .awb { font-size: 15px; font-weight: 800; letter-spacing: .2px; }
        .status { font-size: 12px; font-weight: 700; padding: 5px 9px; border-radius: 999px; white-space: nowrap; }
        .ready { background: rgba(76, 175, 80, .16); color: #81c784; }
        .active { background: rgba(33, 150, 243, .16); color: #64b5f6; }
        .delivered { background: rgba(158, 158, 158, .16); color: var(--secondary-text-color); }
        .problem { background: rgba(244, 67, 54, .16); color: #ef9a9a; }
        .sender { font-weight: 700; margin: 12px 0 8px; line-height: 1.35; }
        .line { display: flex; justify-content: space-between; gap: 12px; padding: 6px 0; border-top: 1px solid var(--divider-color); font-size: 13px; }
        .line:first-of-type { border-top: 0; }
        .key { color: var(--secondary-text-color); }
        .val { text-align: right; font-weight: 600; }
        .empty { padding: 28px; text-align: center; color: var(--secondary-text-color); }
        .drawer-backdrop { position: fixed; inset: 0; background: rgba(0, 0, 0, .48); z-index: 10; display: flex; justify-content: flex-end; }
        .drawer { width: min(620px, calc(100vw - 22px)); height: 100vh; background: var(--card-background-color); border-left: 1px solid var(--divider-color); box-shadow: -10px 0 28px rgba(0, 0, 0, .22); overflow: auto; }
        .drawer-head { position: sticky; top: 0; z-index: 1; background: var(--card-background-color); border-bottom: 1px solid var(--divider-color); padding: 18px 20px; display: flex; align-items: center; justify-content: space-between; gap: 14px; }
        .drawer-title { font-size: 20px; font-weight: 800; margin: 0; }
        .drawer-subtitle { color: var(--secondary-text-color); font-size: 13px; margin-top: 4px; }
        .drawer-actions { display: flex; gap: 8px; align-items: center; }
        .icon-button { border: 1px solid var(--divider-color); background: var(--secondary-background-color); color: var(--primary-text-color); border-radius: 999px; min-width: 36px; height: 36px; cursor: pointer; font-size: 18px; }
        .drawer-body { padding: 18px 20px 30px; }
        .detail-section { border: 1px solid var(--divider-color); border-radius: 16px; padding: 14px; margin-bottom: 14px; background: var(--secondary-background-color); }
        .detail-section h2 { font-size: 15px; margin: 0 0 10px; }
        .detail-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 8px; }
        .detail-item { border-top: 1px solid var(--divider-color); padding: 8px 0; min-width: 0; }
        .detail-item:first-child, .detail-item:nth-child(2) { border-top: 0; }
        .detail-label { color: var(--secondary-text-color); font-size: 12px; margin-bottom: 3px; }
        .detail-value { font-weight: 700; word-break: break-word; }
        .timeline { margin: 4px 0 0; padding: 0; list-style: none; }
        .timeline-item { position: relative; padding: 0 0 18px 26px; border-left: 2px solid var(--divider-color); margin-left: 9px; }
        .timeline-item:last-child { padding-bottom: 0; }
        .timeline-dot { position: absolute; left: -9px; top: 0; width: 16px; height: 16px; border-radius: 999px; background: var(--primary-color); box-shadow: 0 0 0 4px var(--card-background-color); }
        .timeline-status { font-weight: 800; margin-bottom: 3px; }
        .timeline-meta { color: var(--secondary-text-color); font-size: 12px; line-height: 1.45; }
        .timeline-normalized { display: inline-block; margin-top: 5px; padding: 3px 7px; border-radius: 999px; background: rgba(158, 158, 158, .16); font-size: 11px; font-weight: 700; color: var(--secondary-text-color); }
        .mono { font-family: var(--code-font-family, monospace); }
        @media (max-width: 760px) { .stats { grid-template-columns: repeat(2, minmax(0, 1fr)); } .helpers { grid-template-columns: 1fr; } .helper-card { display: block; } .helper-button { margin-top: 12px; width: 100%; } .header { display: block; } .detail-grid { grid-template-columns: 1fr; } .detail-item:nth-child(2) { border-top: 1px solid var(--divider-color); } .drawer { width: 100vw; } }
      </style>
      <div class="wrap">
        <div class="header">
          <div>
            <h1>Curieri Romania</h1>
            <div class="subtitle">Dashboard colete si statusuri curieri</div>
          </div>
        </div>
        <div class="stats">
          <div class="stat"><div class="label">Colete active</div><div class="value">${active}</div></div>
          <div class="stat"><div class="label">Disponibile la ridicare</div><div class="value">${ready}</div></div>
          <div class="stat"><div class="label">Livrate</div><div class="value">${delivered}</div></div>
          <div class="stat"><div class="label">Cu probleme</div><div class="value">${problems}</div></div>
        </div>
        <div class="helpers">
          <div class="helper-card">
            <div>
              <div class="helper-title">Helper Sameday</div>
              <div class="helper-text">Deschide pagina locala cu instructiuni si bookmarklet pentru extragerea refresh tokenului Sameday.</div>
            </div>
            <button class="helper-button js-helper" data-helper="sameday">Deschide helper</button>
          </div>
          <div class="helper-card">
            <div>
              <div class="helper-title">Helper Cargus</div>
              <div class="helper-text">Deschide pagina locala cu instructiuni si bookmarklet pentru extragerea refresh tokenului MyCargus.</div>
            </div>
            <button class="helper-button js-helper" data-helper="cargus">Deschide helper</button>
          </div>
        </div>
        ${parcels.length ? `<div class="grid">${parcels.map((parcel) => this._parcelCard(parcel)).join("")}</div>` : `<div class="card empty">Nu exista colete inregistrate momentan.</div>`}
        ${selectedParcel ? this._detailDrawer(selectedParcel) : ""}
      </div>
    `;
    for (const el of this.shadowRoot.querySelectorAll(".card[data-entity]")) {
      el.addEventListener("click", () => this._openDetails(el.getAttribute("data-entity")));
    }
    const backdrop = this.shadowRoot.querySelector(".drawer-backdrop");
    if (backdrop) {
      backdrop.addEventListener("click", (event) => {
        if (event.target === backdrop) this._closeDetails();
      });
    }
    const closeButton = this.shadowRoot.querySelector(".js-close-details");
    if (closeButton) closeButton.addEventListener("click", () => this._closeDetails());
    const moreInfoButton = this.shadowRoot.querySelector(".js-more-info");
    if (moreInfoButton) moreInfoButton.addEventListener("click", () => this._openEntity(moreInfoButton.getAttribute("data-entity")));
    for (const helperButton of this.shadowRoot.querySelectorAll(".js-helper")) {
      helperButton.addEventListener("click", () => this._openHelper(helperButton.getAttribute("data-helper")));
    }
  }


  _eventTime(event) {
    return event?.event_time || event?.time || event?.date || event?.timestamp || null;
  }

  _eventStatus(event) {
    return event?.status || event?.name || event?.description || "Eveniment";
  }

  _eventLocation(event) {
    return event?.location || event?.city || event?.locality || "";
  }

  _eventNormalizedStatus(event) {
    return event?.normalized_status || event?.normalizedStatus || "";
  }

  _detailItem(label, value, formatter = null) {
    const rawValue = value === null || value === undefined || value === "" ? "Necunoscut" : value;
    const displayValue = formatter ? formatter(rawValue) : rawValue;
    return `
      <div class="detail-item">
        <div class="detail-label">${this._escape(label)}</div>
        <div class="detail-value">${this._escape(displayValue)}</div>
      </div>
    `;
  }

  _detailDrawer(parcel) {
    const events = [...(parcel.events || [])].sort((a, b) => {
      const aTime = new Date(this._eventTime(a) || 0).getTime();
      const bTime = new Date(this._eventTime(b) || 0).getTime();
      return aTime - bTime;
    });
    const className = this._statusClass(parcel);
    return `
      <div class="drawer-backdrop">
        <aside class="drawer" role="dialog" aria-label="Detalii colet">
          <div class="drawer-head">
            <div>
              <div class="drawer-title">${this._escape(parcel.awbShort)}</div>
              <div class="drawer-subtitle">${this._escape(parcel.courier)} · ${this._escape(parcel.sender || "Necunoscut")}</div>
            </div>
            <div class="drawer-actions">
              <button class="icon-button js-more-info" data-entity="${this._escape(parcel.entityId)}" title="Deschide entitatea Home Assistant">⌘</button>
              <button class="icon-button js-close-details" title="Inchide">×</button>
            </div>
          </div>
          <div class="drawer-body">
            <div class="detail-section">
              <div class="top">
                <div>
                  <h2>Rezumat colet</h2>
                  <div class="drawer-subtitle mono">AWB: ${this._escape(parcel.awb)}</div>
                </div>
                <div class="status ${className}">${this._escape(parcel.status)}</div>
              </div>
              <div class="detail-grid">
                ${this._detailItem("Curier", parcel.courier)}
                ${this._detailItem("Directie", parcel.direction)}
                ${this._detailItem("Expeditor", parcel.sender)}
                ${this._detailItem("Destinatar", parcel.recipient)}
                ${this._detailItem("Status original", parcel.originalStatus)}
                ${this._detailItem("Status normalizat", parcel.status)}
                ${this._detailItem("Locatie", parcel.location || parcel.lockerName)}
                ${this._detailItem("Locker / punct ridicare", parcel.lockerName)}
                ${this._detailItem("Ramburs", parcel.cod, (value) => this._formatMoney(value))}
                ${this._detailItem("PIN expira", parcel.pinExpiration, (value) => this._formatDate(value))}
                ${this._detailItem("Estimare livrare", parcel.attributes.estimated_delivery, (value) => this._formatDate(value))}
                ${this._detailItem("Livrat la", parcel.deliveredAt, (value) => this._formatDate(value))}
                ${this._detailItem("Ultima actualizare", parcel.lastUpdate, (value) => this._formatDate(value))}
                ${this._detailItem("Tip livrare", parcel.attributes.delivery_type || parcel.attributes.deliveryType)}
              </div>
            </div>
            <div class="detail-section">
              <h2>Istoric livrare</h2>
              ${events.length ? this._timeline(events) : `<div class="empty">Nu exista evenimente detaliate pentru acest colet.</div>`}
            </div>
          </div>
        </aside>
      </div>
    `;
  }

  _timeline(events) {
    return `
      <ol class="timeline">
        ${events.map((event) => {
          const status = this._eventStatus(event);
          const time = this._eventTime(event);
          const location = this._eventLocation(event);
          const normalized = this._eventNormalizedStatus(event);
          return `
            <li class="timeline-item">
              <span class="timeline-dot"></span>
              <div class="timeline-status">${this._escape(status)}</div>
              <div class="timeline-meta">
                ${this._escape(this._formatDate(time))}${location ? ` · ${this._escape(location)}` : ""}
              </div>
              ${normalized ? `<div class="timeline-normalized">${this._escape(normalized)}</div>` : ""}
            </li>
          `;
        }).join("")}
      </ol>
    `;
  }

  _parcelCard(parcel) {
    const className = this._statusClass(parcel);
    const title = parcel.sender && parcel.sender !== "Necunoscut" ? parcel.sender : parcel.friendlyName;
    const where = parcel.location || parcel.lockerName || "Necunoscut";
    return `
      <div class="card" data-entity="${this._escape(parcel.entityId)}">
        <div class="top">
          <div class="awb">${this._escape(parcel.awbShort)}</div>
          <div class="status ${className}">${this._escape(parcel.status)}</div>
        </div>
        <div class="sender">${this._escape(title)}</div>
        <div class="line"><span class="key">Curier</span><span class="val">${this._escape(parcel.courier)}</span></div>
        <div class="line"><span class="key">Locatie</span><span class="val">${this._escape(where)}</span></div>
        <div class="line"><span class="key">Ramburs</span><span class="val">${this._formatMoney(parcel.cod)}</span></div>
        <div class="line"><span class="key">PIN expira</span><span class="val">${this._escape(this._formatDate(parcel.pinExpiration))}</span></div>
        <div class="line"><span class="key">Ultima actualizare</span><span class="val">${this._escape(this._formatDate(parcel.lastUpdate))}</span></div>
      </div>
    `;
  }
}

customElements.define("curieri-romania-panel", CurieriRomaniaPanel);
