"""Constante pentru integrarea Curieri Romania."""

from __future__ import annotations

from datetime import timedelta
from typing import Final

DOMAIN: Final = "curieri_romania"
NAME: Final = "Curieri Romania"
VERSION: Final = "0.6.6"

PLATFORMS: Final = ["sensor", "button"]

DEFAULT_SCAN_INTERVAL: Final = timedelta(minutes=30)
MIN_SCAN_INTERVAL: Final = timedelta(minutes=10)

CONF_COURIER: Final = "courier"
CONF_ENABLED_COURIERS: Final = "enabled_couriers"
CONF_INSTANCE_NAME: Final = "instance_name"

CONF_ENTRY_TYPE: Final = "entry_type"
ENTRY_TYPE_ADMIN: Final = "admin"
ENTRY_TYPE_COURIER: Final = "courier"

ADMIN_UNIQUE_ID: Final = f"{DOMAIN}_admin"
ADMIN_ENTRY_TITLE: Final = "Administrare Curieri Romania"

CONF_SAMEDAY_ACCESS_TOKEN: Final = "sameday_access_token"
CONF_SAMEDAY_REFRESH_TOKEN: Final = "sameday_refresh_token"
CONF_SAMEDAY_ID_TOKEN: Final = "sameday_id_token"
CONF_SAMEDAY_TOKEN_EXPIRES_AT: Final = "sameday_token_expires_at"
CONF_SAMEDAY_TOKEN_TYPE: Final = "sameday_token_type"
CONF_SAMEDAY_SCOPE: Final = "sameday_scope"

CONF_FAN_USERNAME: Final = "fan_username"
CONF_FAN_PASSWORD: Final = "fan_password"
CONF_FAN_API_KEY: Final = "fan_api_key"
CONF_FAN_PHONE: Final = "fan_phone"

CONF_CARGUS_PHONE: Final = "cargus_phone"
CONF_CARGUS_ACCESS_TOKEN: Final = "cargus_access_token"
CONF_CARGUS_REFRESH_TOKEN: Final = "cargus_refresh_token"
CONF_CARGUS_TOKEN_EXPIRES_AT: Final = "cargus_token_expires_at"

CONF_GLS_ACCESS_TOKEN: Final = "gls_access_token"
CONF_GLS_REFRESH_TOKEN: Final = "gls_refresh_token"
CONF_GLS_TOKEN_EXPIRES_AT: Final = "gls_token_expires_at"

COURIER_SAMEDAY: Final = "sameday"
COURIER_FAN: Final = "fan_courier"
COURIER_CARGUS: Final = "cargus"
COURIER_GLS: Final = "gls"

COURIER_NAMES: Final = {
    COURIER_SAMEDAY: "Sameday",
    COURIER_FAN: "FAN Courier",
    COURIER_CARGUS: "Cargus",
    COURIER_GLS: "GLS",
}

SUPPORTED_COURIERS: Final = [COURIER_SAMEDAY, COURIER_FAN, COURIER_CARGUS, COURIER_GLS]
PLANNED_COURIERS: Final = []

ATTR_COURIER: Final = "courier"
ATTR_AWB: Final = "awb"
ATTR_DIRECTION: Final = "direction"
ATTR_ORIGINAL_STATUS: Final = "original_status"
ATTR_NORMALIZED_STATUS: Final = "normalized_status"
ATTR_LAST_UPDATE: Final = "last_update"
ATTR_LOCATION: Final = "location"
ATTR_SENDER: Final = "sender"
ATTR_RECIPIENT: Final = "recipient"
